// ================================================================
// Roll — Best-in-Class Web Clone
// Real TF.js vision + FFmpeg.wasm + privacy-first architecture
// ================================================================

const state = {
  currentScreen: 'home',
  selectedTemplate: null,
  media: [],            // { file, url, type, meta, score, labels, selected }
  customAudio: null,
  branding: {
    color: '#ffffff', mode: 'text', hue: 0,
    saturation: 100, brightness: 100, font: 'Inter', style: 'normal'
  },
  captions: ['CONFIGURE YOUR', "BRAND'S CAPTION STYLE"],
  quality: 'fast',
  ffmpeg: null,
  ffmpegLoaded: false,
  cocoModel: null,
  renderedBlob: null,
  analysisRunning: false,
  muted: true
};

const templates = [
  { id: 1, title: 'Fitness Transformation', niche: 'Fitness • Bodybuilding', scenes: 28, preferred: ['person', 'sports ball'], gradient: 'linear-gradient(135deg,#1e3a5f,#0f766e)' },
  { id: 2, title: 'Mindset & Growth', niche: 'Lifestyle • Personal Growth', scenes: 22, preferred: ['person', 'book'], gradient: 'linear-gradient(135deg,#4c1d95,#7c3aed)' },
  { id: 3, title: 'Travel Adventure', niche: 'Travel • Adventure', scenes: 19, preferred: ['person', 'car', 'airplane', 'boat', 'mountain'], gradient: 'linear-gradient(135deg,#9a3412,#ea580c)' },
  { id: 4, title: 'Healthy Recipes', niche: 'Nutrition • Lifestyle', scenes: 37, preferred: ['bowl', 'cup', 'bottle', 'orange', 'apple', 'banana'], gradient: 'linear-gradient(135deg,#166534,#22c55e)' },
  { id: 5, title: 'Day in the Life', niche: 'Lifestyle • Vlog', scenes: 15, preferred: ['person', 'laptop', 'cell phone', 'cup'], gradient: 'linear-gradient(135deg,#1e1b4b,#312e81)' }
];

const colors = ['#ffffff','#000000','#ef4444','#f97316','#eab308','#22c55e','#06b6d4','#3b82f6','#8b5cf6','#ec4899'];

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------------- Navigation ----------------
function showScreen(id) {
  $$('.screen').forEach(s => s.classList.remove('active'));
  const el = $(`#screen-${id}`);
  if (el) { el.classList.add('active'); state.currentScreen = id; }
  $('#back-btn').style.visibility = id === 'home' ? 'hidden' : 'visible';
}

// ---------------- Templates ----------------
function renderTemplates() {
  $('#templates-grid').innerHTML = templates.map(t => `
    <div class="template-card" data-id="${t.id}">
      <div class="template-thumb" style="background:${t.gradient}">
        <div class="template-meta">
          <div class="niche">${t.niche}</div>
          <h4>${t.title}</h4>
        </div>
      </div>
      <div class="template-info">
        <span class="scenes">${t.scenes} Scenes • AI match</span>
        <button class="use-btn" data-id="${t.id}">Use</button>
      </div>
    </div>`).join('');

  $$('.use-btn, .template-card').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const id = parseInt(el.dataset.id || el.closest('.template-card')?.dataset.id);
      if (id) {
        state.selectedTemplate = templates.find(t => t.id === id);
        showScreen('branding');
        updateCaptionPreview();
      }
    });
  });
}

// ---------------- Branding ----------------
function initBranding() {
  $('#color-palette').innerHTML = colors.map((c,i) =>
    `<div class="color-swatch ${i===0?'active':''}" style="background:${c}" data-color="${c}"></div>`
  ).join('');

  $$('.color-swatch').forEach(s => s.addEventListener('click', () => {
    $$('.color-swatch').forEach(x => x.classList.remove('active'));
    s.classList.add('active');
    state.branding.color = s.dataset.color;
    updateCaptionPreview();
  }));

  $$('.tab').forEach(tab => tab.addEventListener('click', () => {
    $$('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const t = tab.dataset.tab;
    $('#color-controls').classList.toggle('hidden', t !== 'color');
    $('#font-controls').classList.toggle('hidden', t !== 'font');
    $('#style-controls').classList.toggle('hidden', t !== 'style');
  }));

  $$('input[name="text-mode"]').forEach(r => r.addEventListener('change', () => {
    state.branding.mode = r.value; updateCaptionPreview();
  }));

  ['hue','sat','bri'].forEach(k => {
    const slider = $(`#${k}-slider`), val = $(`#${k}-val`);
    slider.addEventListener('input', () => {
      const map = {hue:'hue',sat:'saturation',bri:'brightness'};
      state.branding[map[k]] = +slider.value;
      val.textContent = slider.value;
      updateCaptionPreview();
    });
  });

  $$('.font-option').forEach(b => b.addEventListener('click', () => {
    $$('.font-option').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    state.branding.font = b.dataset.font;
    updateCaptionPreview();
  }));

  $$('.style-btn').forEach(b => b.addEventListener('click', () => {
    $$('.style-btn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    state.branding.style = b.dataset.style;
    updateCaptionPreview();
  }));

  $('#continue-branding').addEventListener('click', () => showScreen('media'));
}

function updateCaptionPreview() {
  const el = $('#live-caption');
  if (!el) return;
  const b = state.branding;
  el.style.filter = `hue-rotate(${b.hue}deg) saturate(${b.saturation}%) brightness(${b.brightness}%)`;
  el.style.color = b.mode === 'text' ? b.color : 'transparent';
  el.style.webkitTextStroke = b.mode === 'stroke' ? `2px ${b.color}` : '0';
  el.style.fontFamily = b.font;
  el.style.fontWeight = b.style === 'bold' ? '800' : '700';
  el.style.textTransform = b.style === 'uppercase' ? 'uppercase' : 'none';
  el.style.textShadow = b.style === 'shadow' ? '0 4px 12px rgba(0,0,0,0.6)' : '0 2px 8px rgba(0,0,0,0.4)';
}

// ---------------- Media ----------------
function initMedia() {
  const zone = $('#upload-zone'), input = $('#file-input');
  zone.addEventListener('click', () => input.click());
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => { e.preventDefault(); zone.classList.remove('dragover'); handleFiles(e.dataTransfer.files); });
  input.addEventListener('change', () => handleFiles(input.files));

  $$('input[name="audio"]').forEach(r => r.addEventListener('change', () => {
    if (r.value === 'custom') $('#audio-input').click();
    else { state.customAudio = null; $('#audio-hint').textContent = ''; }
  }));
  $('#audio-input').addEventListener('change', e => {
    const f = e.target.files[0];
    if (f) {
      if (state.customAudio) URL.revokeObjectURL(state.customAudio.url);
      state.customAudio = { file: f, url: URL.createObjectURL(f) };
      $('#audio-hint').textContent = `Using: ${f.name}`;
    }
  });

  $$('input[name="quality"]').forEach(r => r.addEventListener('change', () => {
    state.quality = r.value;
  }));

  $('#generate-btn').addEventListener('click', () => runVisionAnalysis());
}

async function handleFiles(fileList) {
  const files = Array.from(fileList).slice(0, 12);
  for (const file of files) {
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) continue;
    const url = URL.createObjectURL(file);
    const type = file.type.startsWith('video/') ? 'video' : 'image';
    const meta = await extractMeta(file, url, type);
    state.media.push({ file, url, type, meta, score: 0, labels: [], selected: true });
  }
  renderMediaGrid();
  $('#generate-btn').disabled = state.media.length === 0;
}

async function extractMeta(file, url, type) {
  const meta = { name: file.name, size: file.size, duration: 0, width: 0, height: 0, brightness: 0.5, aspect: 1 };
  if (type === 'image') {
    const img = new Image();
    await new Promise(r => { img.onload = r; img.src = url; });
    meta.width = img.naturalWidth; meta.height = img.naturalHeight;
    meta.aspect = meta.width / meta.height;
    meta.brightness = await measureBrightness(img);
  } else {
    const video = document.createElement('video');
    video.preload = 'metadata'; video.muted = true;
    await new Promise(r => { video.onloadedmetadata = r; video.src = url; });
    meta.duration = video.duration || 0;
    meta.width = video.videoWidth; meta.height = video.videoHeight;
    meta.aspect = meta.width / (meta.height || 1);
    video.currentTime = Math.min(0.8, meta.duration / 3);
    await new Promise(r => { video.onseeked = r; });
    meta.brightness = await measureBrightness(video);
  }
  return meta;
}

function measureBrightness(el) {
  return new Promise(resolve => {
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    const ctx = c.getContext('2d');
    ctx.drawImage(el, 0, 0, 64, 64);
    const d = ctx.getImageData(0, 0, 64, 64).data;
    let sum = 0;
    for (let i = 0; i < d.length; i += 4) sum += 0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2];
    resolve(sum / (d.length/4) / 255);
  });
}

function renderMediaGrid() {
  $('#media-grid').innerHTML = state.media.map((m, i) => `
    <div class="media-item" data-idx="${i}">
      ${m.type === 'video' ? `<video src="${m.url}" muted></video>` : `<img src="${m.url}" alt="">`}
      <button class="remove" data-index="${i}">×</button>
      ${m.score > 0 ? `<div class="score-badge">${Math.round(m.score)}</div>` : ''}
    </div>`).join('');

  $$('.media-item .remove').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const idx = +btn.dataset.index;
      URL.revokeObjectURL(state.media[idx].url);
      state.media.splice(idx, 1);
      renderMediaGrid();
      $('#generate-btn').disabled = state.media.length === 0;
    });
  });
}

// ---------------- Real Local Vision (TF.js COCO-SSD) ----------------
async function loadCocoModel() {
  if (state.cocoModel) return state.cocoModel;
  $('#analysis-status').textContent = 'Loading vision model…';
  state.cocoModel = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
  return state.cocoModel;
}

async function detectObjects(mediaItem) {
  try {
    const model = await loadCocoModel();
    let element;
    if (mediaItem.type === 'image') {
      element = new Image();
      element.crossOrigin = 'anonymous';
      await new Promise(r => { element.onload = r; element.src = mediaItem.url; });
    } else {
      element = document.createElement('video');
      element.muted = true; element.crossOrigin = 'anonymous';
      await new Promise(r => { element.onloadeddata = r; element.src = mediaItem.url; });
      element.currentTime = Math.min(1, (mediaItem.meta.duration || 2) / 3);
      await new Promise(r => { element.onseeked = r; });
    }
    const predictions = await model.detect(element);
    return predictions
      .filter(p => p.score > 0.45)
      .map(p => ({ class: p.class, score: p.score }));
  } catch (e) {
    console.warn('Detection failed', e);
    return [];
  }
}

async function runVisionAnalysis() {
  if (state.analysisRunning || !state.media.length) return;
  state.analysisRunning = true;

  const panel = $('#analysis-panel');
  const status = $('#analysis-status');
  const progress = $('#analysis-progress');
  const results = $('#analysis-results');
  panel.classList.remove('hidden');
  status.textContent = 'Starting…';
  progress.style.width = '0%';
  results.innerHTML = '';

  try {
    await loadCocoModel();
  } catch (e) {
    status.textContent = 'Vision model unavailable — using heuristics';
  }

  const preferred = state.selectedTemplate?.preferred || [];
  const total = state.media.length;

  for (let i = 0; i < total; i++) {
    const m = state.media[i];
    status.textContent = `Analyzing ${i + 1}/${total}…`;

    // Object detection
    const detections = await detectObjects(m);
    m.labels = detections.map(d => d.class);

    // Scoring
    let score = 35;
    const res = m.meta.width * m.meta.height;
    if (res > 1200000) score += 18;
    else if (res > 500000) score += 10;

    if (m.type === 'video') {
      if (m.meta.duration >= 1.5 && m.meta.duration <= 15) score += 14;
      else if (m.meta.duration > 0) score += 4;
    } else score += 7;

    const aspectDiff = Math.abs(m.meta.aspect - 9/16);
    if (aspectDiff < 0.25) score += 14;
    else if (aspectDiff < 0.55) score += 6;

    if (m.meta.brightness > 0.22 && m.meta.brightness < 0.82) score += 8;

    // Template preference boost
    const matchCount = m.labels.filter(l => preferred.some(p => l.includes(p) || p.includes(l))).length;
    score += matchCount * 12;

    // Presence of people is almost always good for Reels
    if (m.labels.includes('person')) score += 10;

    m.score = Math.min(99, Math.round(score + Math.random() * 5));
    m.selected = m.score >= 52;

    progress.style.width = ((i + 1) / total * 100) + '%';
    await sleep(80);
  }

  // Rank
  state.media.sort((a, b) => b.score - a.score);
  let selected = state.media.filter(m => m.selected);
  if (selected.length < 2) {
    state.media.slice(0, Math.min(5, state.media.length)).forEach(m => m.selected = true);
    selected = state.media.filter(m => m.selected);
  }

  // Keep top 8
  state.media.forEach((m, idx) => { if (idx >= 8) m.selected = false; });

  status.textContent = 'Complete';
  const avg = Math.round(state.media.reduce((s, m) => s + m.score, 0) / total);
  const allLabels = [...new Set(state.media.flatMap(m => m.labels))].slice(0, 8);
  results.innerHTML = `
    Analyzed <strong>${total}</strong> items with on-device vision.<br>
    Selected <strong class="score">${state.media.filter(m=>m.selected).length}</strong> best clips
    (avg score ${avg}).<br>
    Detected: ${allLabels.length ? allLabels.join(', ') : 'general scenes'}.
  `;

  renderMediaGrid();
  state.analysisRunning = false;
  setTimeout(() => generatePreview(), 500);
}

// ---------------- Preview + Timeline ----------------
function generatePreview() {
  showScreen('preview');
  const placeholder = $('#reel-placeholder');
  const video = $('#preview-video');
  const caption = $('#preview-caption');
  const strip = $('#scenes-strip');

  placeholder.style.display = 'flex';
  video.style.display = 'none';
  $('#processing-text').textContent = 'Preparing preview…';
  $('#render-progress').style.width = '40%';

  setTimeout(() => {
    $('#render-progress').style.width = '100%';
    placeholder.style.display = 'none';

    const selected = state.media.filter(m => m.selected);
    if (selected.length) {
      const first = selected[0];
      if (first.type === 'video') {
        video.src = first.url;
        video.muted = state.muted;
        video.style.display = 'block';
        video.play().catch(() => {});
      } else {
        video.style.display = 'none';
        const frame = $('#reel-frame');
        frame.style.backgroundImage = `url(${first.url})`;
        frame.style.backgroundSize = 'cover';
        frame.style.backgroundPosition = 'center';
      }
    }

    caption.textContent = state.captions.join('\n');
    applyCaptionStyle(caption);
    caption.oninput = () => {
      state.captions = caption.innerText.split('\n').filter(Boolean);
    };

    renderTimeline(selected);
  }, 900);
}

function applyCaptionStyle(el) {
  const b = state.branding;
  el.style.color = b.mode === 'text' ? b.color : 'transparent';
  el.style.webkitTextStroke = b.mode === 'stroke' ? `2px ${b.color}` : '0';
  el.style.fontFamily = b.font;
  el.style.fontWeight = b.style === 'bold' ? '800' : '700';
  el.style.textTransform = b.style === 'uppercase' ? 'uppercase' : 'none';
  el.style.filter = `hue-rotate(${b.hue}deg) saturate(${b.saturation}%) brightness(${b.brightness}%)`;
  el.style.textShadow = b.style === 'shadow' ? '0 4px 12px rgba(0,0,0,0.7)' : '0 2px 8px rgba(0,0,0,0.5)';
}

function renderTimeline(selected) {
  const strip = $('#scenes-strip');
  strip.innerHTML = selected.map((m, i) => `
    <div class="scene-thumb ${i===0?'active':''}" draggable="true" data-idx="${i}">
      ${m.type === 'video' ? `<video src="${m.url}" muted></video>` : `<img src="${m.url}">`}
      <div class="scene-score">${m.score}</div>
      ${m.labels.length ? `<div class="scene-labels">${m.labels.slice(0,2).join(', ')}</div>` : ''}
    </div>
  `).join('');

  // Drag & drop reorder
  let dragSrc = null;
  $$('.scene-thumb').forEach(thumb => {
    thumb.addEventListener('dragstart', e => {
      dragSrc = thumb;
      thumb.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    thumb.addEventListener('dragend', () => thumb.classList.remove('dragging'));
    thumb.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
    thumb.addEventListener('drop', e => {
      e.preventDefault();
      if (dragSrc && dragSrc !== thumb) {
        const from = +dragSrc.dataset.idx;
        const to = +thumb.dataset.idx;
        const selected = state.media.filter(m => m.selected);
        const item = selected.splice(from, 1)[0];
        selected.splice(to, 0, item);
        // Rebuild selection order in state.media
        const unselected = state.media.filter(m => !m.selected);
        state.media = [...selected, ...unselected];
        renderTimeline(selected);
      }
    });
  });
}

// ---------------- FFmpeg Rendering ----------------
function getFFmpeg() {
  if (window.FFmpegWASM && window.FFmpegWASM.FFmpeg) return window.FFmpegWASM.FFmpeg;
  if (window.FFmpeg) return window.FFmpeg;
  return null;
}
function getUtil() {
  return window.FFmpegUtil || {};
}

async function loadFFmpeg() {
  if (state.ffmpegLoaded) return state.ffmpeg;
  const FFmpegClass = getFFmpeg();
  if (!FFmpegClass) throw new Error('FFmpeg.wasm not loaded');

  const ffmpeg = new FFmpegClass();
  state.ffmpeg = ffmpeg;

  ffmpeg.on('log', ({ message }) => console.log('[ffmpeg]', message));
  ffmpeg.on('progress', ({ progress }) => {
    const pct = Math.min(98, Math.round(progress * 100));
    $('#render-progress').style.width = pct + '%';
    $('#processing-text').textContent = `Rendering ${pct}%`;
  });

  const { toBlobURL } = getUtil();
  const base = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
  await ffmpeg.load({
    coreURL: await toBlobURL(`${base}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${base}/ffmpeg-core.wasm`, 'application/wasm')
  });
  state.ffmpegLoaded = true;
  return ffmpeg;
}

async function renderAndExport() {
  showScreen('preview');
  const placeholder = $('#reel-placeholder');
  const videoEl = $('#preview-video');
  placeholder.style.display = 'flex';
  videoEl.style.display = 'none';
  $('#processing-text').textContent = 'Loading FFmpeg.wasm…';
  $('#render-progress').style.width = '3%';

  try {
    const ffmpeg = await loadFFmpeg();
    const { fetchFile } = getUtil();
    const selected = state.media.filter(m => m.selected).slice(0, 7);
    if (!selected.length) throw new Error('No clips selected');

    $('#processing-text').textContent = 'Writing media…';
    for (let i = 0; i < selected.length; i++) {
      const data = await fetchFile(selected[i].file);
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      await ffmpeg.writeFile(`in${i}.${ext}`, data);
    }

    if (state.customAudio) {
      const adata = await fetchFile(state.customAudio.file);
      await ffmpeg.writeFile('audio.mp3', adata);
    }

    const preset = state.quality === 'high' ? 'medium' : state.quality === 'balanced' ? 'fast' : 'ultrafast';
    const crf = state.quality === 'high' ? '20' : state.quality === 'balanced' ? '24' : '28';

    // Build filter: scale+pad each to 1080x1920, short duration, then concat
    const inputs = [];
    const filters = [];
    for (let i = 0; i < selected.length; i++) {
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      inputs.push('-i', `in${i}.${ext}`);
      const dur = selected[i].type === 'image' ? 2.8 : 3.8;
      filters.push(`[${i}:v]scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,trim=duration=${dur},setpts=PTS-STARTPTS[v${i}]`);
    }

    const concat = selected.map((_, i) => `[v${i}]`).join('') + `concat=n=${selected.length}:v=1:a=0[outv]`;
    const fc = filters.join(';') + ';' + concat;

    $('#processing-text').textContent = 'Compositing scenes…';
    const args = [
      ...inputs,
      '-filter_complex', fc,
      '-map', '[outv]',
      '-c:v', 'libx264',
      '-preset', preset,
      '-crf', crf,
      '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart',
      'temp.mp4'
    ];
    await ffmpeg.exec(args);

    // Optional audio + caption burn
    $('#processing-text').textContent = 'Finalizing…';
    const captionText = ($('#preview-caption')?.innerText || state.captions.join(' '))
      .replace(/\n/g, ' ').replace(/'/g, '').replace(/:/g, ' ').slice(0, 80);
    const fontcolor = (state.branding.mode === 'text' ? state.branding.color : '#FFFFFF').replace('#', '');

    const finalArgs = ['-i', 'temp.mp4'];
    if (state.customAudio) {
      finalArgs.push('-i', 'audio.mp3', '-shortest');
    }

    // Try drawtext; fall back gracefully
    try {
      finalArgs.push(
        '-vf', `drawtext=text='${captionText}':fontsize=40:fontcolor=${fontcolor}:x=(w-text_w)/2:y=h-h/5:box=1:boxcolor=black@0.45:boxborderw=10`,
        '-c:v', 'libx264', '-preset', preset, '-crf', crf, '-pix_fmt', 'yuv420p'
      );
      if (state.customAudio) finalArgs.push('-c:a', 'aac', '-b:a', '128k');
      finalArgs.push('out.mp4');
      await ffmpeg.exec(finalArgs);
    } catch (e) {
      console.warn('Caption burn failed, exporting without text overlay', e);
      const fallback = ['-i', 'temp.mp4'];
      if (state.customAudio) fallback.push('-i', 'audio.mp3', '-c:v', 'copy', '-c:a', 'aac', '-shortest');
      else fallback.push('-c', 'copy');
      fallback.push('out.mp4');
      await ffmpeg.exec(fallback);
    }

    const data = await ffmpeg.readFile('out.mp4');
    state.renderedBlob = new Blob([data.buffer], { type: 'video/mp4' });

    // Cleanup
    for (let i = 0; i < selected.length; i++) {
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      try { await ffmpeg.deleteFile(`in${i}.${ext}`); } catch(_){}
    }
    try { await ffmpeg.deleteFile('temp.mp4'); } catch(_){}
    try { await ffmpeg.deleteFile('out.mp4'); } catch(_){}
    if (state.customAudio) try { await ffmpeg.deleteFile('audio.mp3'); } catch(_){}

    const sizeMB = (state.renderedBlob.size / 1024 / 1024).toFixed(1);
    $('#export-meta').innerHTML = `
      ${selected.length} scenes • ${state.quality} quality • ${sizeMB} MB<br>
      Template: ${state.selectedTemplate?.title || 'Custom'} • On-device render
    `;
    showScreen('export');
  } catch (err) {
    console.error(err);
    $('#processing-text').textContent = 'Render failed';
    alert('Render error: ' + (err.message || err) + '\n\nTry fewer / shorter clips, or switch to Fast quality.');
    placeholder.style.display = 'none';
  }
}

// ---------------- Export + Nav ----------------
function initExport() {
  $('#export-btn').addEventListener('click', () => renderAndExport());
  $('#back-to-media').addEventListener('click', () => showScreen('media'));

  $('#download-btn').addEventListener('click', () => {
    if (!state.renderedBlob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(state.renderedBlob);
    a.download = `roll-reel-${Date.now()}.mp4`;
    a.click();
  });

  $('#share-ig-btn').addEventListener('click', async () => {
    if (!state.renderedBlob || !navigator.share) {
      alert('Web Share not available — use Download.');
      return;
    }
    try {
      const file = new File([state.renderedBlob], 'roll-reel.mp4', { type: 'video/mp4' });
      await navigator.share({ files: [file], title: 'My Reel' });
    } catch (e) { console.log(e); }
  });

  $('#create-another').addEventListener('click', () => {
    state.media.forEach(m => URL.revokeObjectURL(m.url));
    state.media = [];
    if (state.customAudio) URL.revokeObjectURL(state.customAudio.url);
    state.customAudio = null;
    state.renderedBlob = null;
    renderMediaGrid();
    $('#generate-btn').disabled = true;
    $('#analysis-panel').classList.add('hidden');
    showScreen('home');
  });

  $('#reanalyze-btn')?.addEventListener('click', () => {
    showScreen('media');
    runVisionAnalysis();
  });

  $('#edit-captions-btn')?.addEventListener('click', () => {
    const c = $('#preview-caption');
    if (c) { c.focus(); document.execCommand('selectAll', false, null); }
  });

  $('#toggle-mute-btn')?.addEventListener('click', () => {
    state.muted = !state.muted;
    const v = $('#preview-video');
    if (v) v.muted = state.muted;
    $('#toggle-mute-btn').innerHTML = state.muted ? '<span>🔇</span> Mute' : '<span>🔊</span> Sound';
  });
}

function initNav() {
  $('#back-btn').addEventListener('click', () => {
    const map = { branding:'home', media:'branding', preview:'media', export:'preview' };
    if (map[state.currentScreen]) showScreen(map[state.currentScreen]);
  });

  $('#privacy-btn').addEventListener('click', () => {
    alert(
      'Privacy Guarantee\n\n' +
      '• Media never leaves this device\n' +
      '• TensorFlow.js + COCO-SSD run 100% locally\n' +
      '• FFmpeg.wasm renders the final MP4 in your browser\n' +
      '• No accounts, no servers, no tracking of your content\n' +
      '• Refresh the page to wipe everything'
    );
  });

  $$('.tab-item').forEach(item => item.addEventListener('click', () => {
    $$('.tab-item').forEach(t => t.classList.remove('active'));
    item.classList.add('active');
    showScreen('home');
  }));
}

function updateTime() {
  const n = new Date();
  $('#status-time').textContent =
    n.getHours().toString().padStart(2,'0') + ':' + n.getMinutes().toString().padStart(2,'0');
}

document.addEventListener('DOMContentLoaded', () => {
  renderTemplates();
  initBranding();
  initMedia();
  initExport();
  initNav();
  updateTime();
  setInterval(updateTime, 30000);
});
