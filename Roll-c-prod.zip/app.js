// ================================================================
// Roll — Camera Roll → Reels (privacy-first, on-device) v0.3
// TF.js vision + FFmpeg.wasm • canvas captions • multi-clip preview
// ================================================================

const LIMITS = {
  maxFiles: 12,
  maxFileBytes: 25 * 1024 * 1024,
  maxTotalBytes: 80 * 1024 * 1024,
  maxVideoSeconds: 60
};

const state = {
  currentScreen: 'home',
  selectedTemplate: null,
  media: [],
  customAudio: null,
  branding: {
    color: '#ffffff', mode: 'text', hue: 0,
    saturation: 100, brightness: 100, font: 'Inter', style: 'normal'
  },
  captions: ['CONFIGURE YOUR', "BRAND'S CAPTION STYLE"],
  quality: 'fast',
  ffmpeg: null,
  ffmpegLoaded: false,
  cocoModel: null,
  renderedBlob: null,
  analysisRunning: false,
  muted: true,
  previewTimer: null,
  previewIndex: 0,
  previewPlaying: false
};

const templates = [
  { id: 1, title: 'Fitness Transformation', niche: 'Fitness • Bodybuilding', scenes: 28, preferred: ['person', 'sports ball'], gradient: 'linear-gradient(135deg,#1e3a5f,#0f766e)' },
  { id: 2, title: 'Mindset & Growth', niche: 'Lifestyle • Personal Growth', scenes: 22, preferred: ['person', 'book'], gradient: 'linear-gradient(135deg,#4c1d95,#7c3aed)' },
  { id: 3, title: 'Travel Adventure', niche: 'Travel • Adventure', scenes: 19, preferred: ['person', 'car', 'airplane', 'boat', 'mountain'], gradient: 'linear-gradient(135deg,#9a3412,#ea580c)' },
  { id: 4, title: 'Healthy Recipes', niche: 'Nutrition • Lifestyle', scenes: 37, preferred: ['bowl', 'cup', 'bottle', 'orange', 'apple', 'banana'], gradient: 'linear-gradient(135deg,#166534,#22c55e)' },
  { id: 5, title: 'Day in the Life', niche: 'Lifestyle • Vlog', scenes: 15, preferred: ['person', 'laptop', 'cell phone', 'cup'], gradient: 'linear-gradient(135deg,#1e1b4b,#312e81)' }
];

const colors = ['#ffffff','#000000','#ef4444','#f97316','#eab308','#22c55e','#06b6d4','#3b82f6','#8b5cf6','#ec4899'];

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));

let toastTimer = null;
function toast(msg, kind = '') {
  const el = $('#global-toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'global-toast' + (kind ? ' ' + kind : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 3200);
}

function sanitizeCaptionText(text, maxLen = 90) {
  if (!text || typeof text !== 'string') return '';
  let s = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
  if (s.length > maxLen) s = s.slice(0, maxLen).trim();
  return s;
}

function countTemplateMatches(labels = [], preferred = []) {
  if (!labels.length || !preferred.length) return 0;
  return labels.filter(l => preferred.some(p => l.includes(p) || p.includes(l))).length;
}

function computeMediaScore(media, preferred = []) {
  const meta = media.meta || {};
  let score = 35;
  const res = (meta.width || 0) * (meta.height || 0);
  if (res > 1_200_000) score += 18;
  else if (res > 500_000) score += 10;
  if (media.type === 'video') {
    const d = meta.duration || 0;
    if (d >= 1.5 && d <= 15) score += 14;
    else if (d > 0) score += 4;
  } else score += 7;
  const aspectDiff = Math.abs((meta.aspect || 1) - 9 / 16);
  if (aspectDiff < 0.25) score += 14;
  else if (aspectDiff < 0.55) score += 6;
  const b = meta.brightness ?? 0.5;
  if (b > 0.22 && b < 0.82) score += 8;
  score += countTemplateMatches(media.labels || [], preferred) * 12;
  if ((media.labels || []).includes('person')) score += 10;
  return Math.min(99, Math.round(score));
}

function applySelectionRules(media) {
  const sorted = [...media].sort((a, b) => b.score - a.score);
  sorted.forEach(m => { m.selected = m.score >= 52; });
  let selected = sorted.filter(m => m.selected);
  if (selected.length < 2 && sorted.length > 0) {
    sorted.slice(0, Math.min(5, sorted.length)).forEach(m => { m.selected = true; });
    selected = sorted.filter(m => m.selected);
  }
  let kept = 0;
  sorted.forEach(m => {
    if (m.selected) {
      kept += 1;
      if (kept > 8) m.selected = false;
    }
  });
  return sorted;
}

function validateMediaFile(file) {
  if (!file) return { ok: false, reason: 'No file' };
  if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
    return { ok: false, reason: 'Only images and videos are supported' };
  }
  if (file.size > LIMITS.maxFileBytes) {
    return { ok: false, reason: 'File too large (max 25 MB): ' + file.name };
  }
  return { ok: true };
}

function revokeMediaUrl(item) {
  if (item && item.url) {
    try { URL.revokeObjectURL(item.url); } catch (_) {}
    item.url = null;
  }
}

function revokeAllMedia() {
  stopPreviewSequencer();
  state.media.forEach(revokeMediaUrl);
  state.media = [];
  if (state.customAudio && state.customAudio.url) {
    try { URL.revokeObjectURL(state.customAudio.url); } catch (_) {}
  }
  state.customAudio = null;
  state.renderedBlob = null;
}

function showScreen(id) {
  if (id === 'preview' && !state.media.some(m => m.selected)) {
    toast('Select or analyze media first');
    return;
  }
  if (id === 'media' && !state.selectedTemplate) {
    state.selectedTemplate = templates[0];
  }
  $$('.screen').forEach(s => s.classList.remove('active'));
  const el = $('#screen-' + id);
  if (el) {
    el.classList.add('active');
    state.currentScreen = id;
  }
  $('#back-btn').style.visibility = id === 'home' ? 'hidden' : 'visible';
  $$('.tab-item').forEach(t => {
    t.classList.toggle('active', t.dataset.screen === id);
  });
  if (id !== 'preview') stopPreviewSequencer();
}

function renderTemplates() {
  $('#templates-grid').innerHTML = templates.map(t =>
    '<div class="template-card" data-id="' + t.id + '">' +
    '<div class="template-thumb" style="background:' + t.gradient + '">' +
    '<div class="template-meta"><div class="niche">' + t.niche + '</div><h4>' + t.title + '</h4></div></div>' +
    '<div class="template-info"><span class="scenes">' + t.scenes + ' Scenes • AI match</span>' +
    '<button class="use-btn" data-id="' + t.id + '">Use</button></div></div>'
  ).join('');

  $$('.use-btn, .template-card').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const id = parseInt(el.dataset.id || (el.closest('.template-card') && el.closest('.template-card').dataset.id), 10);
      if (id) {
        state.selectedTemplate = templates.find(t => t.id === id);
        showScreen('branding');
        updateCaptionPreview();
      }
    });
  });
}

function initBranding() {
  $('#color-palette').innerHTML = colors.map((c, i) =>
    '<div class="color-swatch ' + (i === 0 ? 'active' : '') + '" style="background:' + c + '" data-color="' + c + '"></div>'
  ).join('');

  $$('.color-swatch').forEach(s => s.addEventListener('click', () => {
    $$('.color-swatch').forEach(x => x.classList.remove('active'));
    s.classList.add('active');
    state.branding.color = s.dataset.color;
    updateCaptionPreview();
  }));

  $$('.tab').forEach(tab => tab.addEventListener('click', () => {
    $$('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const t = tab.dataset.tab;
    $('#color-controls').classList.toggle('hidden', t !== 'color');
    $('#font-controls').classList.toggle('hidden', t !== 'font');
    $('#style-controls').classList.toggle('hidden', t !== 'style');
  }));

  $$('input[name="text-mode"]').forEach(r => r.addEventListener('change', () => {
    state.branding.mode = r.value;
    updateCaptionPreview();
  }));

  ['hue', 'sat', 'bri'].forEach(k => {
    const slider = $('#' + k + '-slider');
    const val = $('#' + k + '-val');
    slider.addEventListener('input', () => {
      const map = { hue: 'hue', sat: 'saturation', bri: 'brightness' };
      state.branding[map[k]] = +slider.value;
      val.textContent = slider.value;
      updateCaptionPreview();
    });
  });

  $$('.font-option').forEach(b => b.addEventListener('click', () => {
    $$('.font-option').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    state.branding.font = b.dataset.font;
    updateCaptionPreview();
  }));

  $$('.style-btn').forEach(b => b.addEventListener('click', () => {
    $$('.style-btn').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    state.branding.style = b.dataset.style;
    updateCaptionPreview();
  }));

  $('#continue-branding').addEventListener('click', () => showScreen('media'));
}

function updateCaptionPreview() {
  const el = $('#live-caption');
  if (!el) return;
  const b = state.branding;
  el.style.filter = 'hue-rotate(' + b.hue + 'deg) saturate(' + b.saturation + '%) brightness(' + b.brightness + '%)';
  el.style.color = b.mode === 'text' ? b.color : 'transparent';
  el.style.webkitTextStroke = b.mode === 'stroke' ? '2px ' + b.color : '0';
  el.style.fontFamily = b.font;
  el.style.fontWeight = b.style === 'bold' ? '800' : '700';
  el.style.textTransform = b.style === 'uppercase' ? 'uppercase' : 'none';
  el.style.textShadow = b.style === 'shadow' ? '0 4px 12px rgba(0,0,0,0.6)' : '0 2px 8px rgba(0,0,0,0.4)';
}

function initMedia() {
  const zone = $('#upload-zone');
  const input = $('#file-input');
  zone.addEventListener('click', () => input.click());
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('dragover');
    handleFiles(e.dataTransfer.files);
  });
  input.addEventListener('change', () => handleFiles(input.files));

  $$('input[name="audio"]').forEach(r => r.addEventListener('change', () => {
    if (r.value === 'custom') $('#audio-input').click();
    else {
      if (state.customAudio && state.customAudio.url) {
        try { URL.revokeObjectURL(state.customAudio.url); } catch (_) {}
      }
      state.customAudio = null;
      $('#audio-hint').textContent = '';
    }
  }));
  $('#audio-input').addEventListener('change', e => {
    const f = e.target.files[0];
    if (f) {
      if (state.customAudio && state.customAudio.url) {
        try { URL.revokeObjectURL(state.customAudio.url); } catch (_) {}
      }
      state.customAudio = { file: f, url: URL.createObjectURL(f) };
      $('#audio-hint').textContent = 'Using: ' + f.name;
    }
  });

  $$('input[name="quality"]').forEach(r => r.addEventListener('change', () => {
    state.quality = r.value;
  }));

  $('#generate-btn').addEventListener('click', () => runVisionAnalysis());
}

async function handleFiles(fileList) {
  const incoming = Array.from(fileList || []).slice(0, LIMITS.maxFiles);
  const errors = [];
  let totalBytes = state.media.reduce((s, m) => s + ((m.file && m.file.size) || 0), 0);

  for (const file of incoming) {
    if (state.media.length >= LIMITS.maxFiles) {
      errors.push('Max ' + LIMITS.maxFiles + ' files reached');
      break;
    }
    const check = validateMediaFile(file);
    if (!check.ok) { errors.push(check.reason); continue; }
    if (totalBytes + file.size > LIMITS.maxTotalBytes) {
      errors.push('Total size limit (~80 MB) would be exceeded by ' + file.name);
      continue;
    }
    const url = URL.createObjectURL(file);
    const type = file.type.startsWith('video/') ? 'video' : 'image';
    try {
      const meta = await extractMeta(file, url, type);
      if (type === 'video' && meta.duration > LIMITS.maxVideoSeconds) {
        revokeMediaUrl({ url });
        errors.push(file.name + ' is too long (max ' + LIMITS.maxVideoSeconds + 's)');
        continue;
      }
      state.media.push({ file, url, type, meta, score: 0, labels: [], selected: true });
      totalBytes += file.size;
    } catch (err) {
      console.warn('Meta extract failed', err);
      try { URL.revokeObjectURL(url); } catch (_) {}
      errors.push('Could not read ' + file.name);
    }
  }

  if (errors.length) toast(errors.slice(0, 3).join(' · '), 'error');
  else if (incoming.length) toast('Added media (' + state.media.length + ' total)', 'ok');

  renderMediaGrid();
  $('#generate-btn').disabled = state.media.length === 0;
  if ($('#file-input')) $('#file-input').value = '';
}

async function extractMeta(file, url, type) {
  const meta = { name: file.name, size: file.size, duration: 0, width: 0, height: 0, brightness: 0.5, aspect: 1 };
  if (type === 'image') {
    const img = new Image();
    await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; img.src = url; });
    meta.width = img.naturalWidth;
    meta.height = img.naturalHeight;
    meta.aspect = meta.width / (meta.height || 1);
    meta.brightness = await measureBrightness(img);
  } else {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    await new Promise((resolve, reject) => { video.onloadedmetadata = resolve; video.onerror = reject; video.src = url; });
    meta.duration = video.duration || 0;
    meta.width = video.videoWidth;
    meta.height = video.videoHeight;
    meta.aspect = meta.width / (meta.height || 1);
    video.currentTime = Math.min(0.8, meta.duration / 3 || 0.1);
    await new Promise(r => { video.onseeked = r; });
    meta.brightness = await measureBrightness(video);
  }
  return meta;
}

function measureBrightness(el) {
  return new Promise(resolve => {
    try {
      const c = document.createElement('canvas');
      c.width = 64; c.height = 64;
      const ctx = c.getContext('2d');
      ctx.drawImage(el, 0, 0, 64, 64);
      const d = ctx.getImageData(0, 0, 64, 64).data;
      let sum = 0;
      for (let i = 0; i < d.length; i += 4) sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      resolve(sum / (d.length / 4) / 255);
    } catch (_) { resolve(0.5); }
  });
}

function renderMediaGrid() {
  $('#media-grid').innerHTML = state.media.map((m, i) =>
    '<div class="media-item" data-idx="' + i + '">' +
    (m.type === 'video' ? '<video src="' + m.url + '" muted></video>' : '<img src="' + m.url + '" alt="">') +
    '<button class="remove" data-index="' + i + '" aria-label="Remove">×</button>' +
    (m.score > 0 ? '<div class="score-badge">' + Math.round(m.score) + '</div>' : '') +
    '</div>'
  ).join('');

  $$('.media-item .remove').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const idx = +btn.dataset.index;
      revokeMediaUrl(state.media[idx]);
      state.media.splice(idx, 1);
      renderMediaGrid();
      $('#generate-btn').disabled = state.media.length === 0;
    });
  });
}

async function loadCocoModel() {
  if (state.cocoModel) return state.cocoModel;
  if (typeof cocoSsd === 'undefined') throw new Error('COCO-SSD not loaded (CDN blocked?)');
  $('#analysis-status').textContent = 'Loading vision model (first time may take a few seconds)…';
  state.cocoModel = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
  return state.cocoModel;
}

async function seekVideo(video, t) {
  return new Promise(resolve => {
    const onSeeked = () => { video.removeEventListener('seeked', onSeeked); resolve(); };
    video.addEventListener('seeked', onSeeked);
    video.currentTime = Math.max(0, Math.min(t, (video.duration || 1) - 0.05));
  });
}

async function detectObjects(mediaItem) {
  try {
    const model = await loadCocoModel();
    const labels = new Set();
    let brightnessSum = 0;
    let brightnessCount = 0;

    if (mediaItem.type === 'image') {
      const element = new Image();
      element.crossOrigin = 'anonymous';
      await new Promise((resolve, reject) => { element.onload = resolve; element.onerror = reject; element.src = mediaItem.url; });
      const predictions = await model.detect(element);
      predictions.filter(p => p.score > 0.45).forEach(p => labels.add(p.class));
      brightnessSum += await measureBrightness(element);
      brightnessCount += 1;
    } else {
      const video = document.createElement('video');
      video.muted = true;
      video.crossOrigin = 'anonymous';
      video.preload = 'auto';
      await new Promise((resolve, reject) => { video.onloadeddata = resolve; video.onerror = reject; video.src = mediaItem.url; });
      const dur = mediaItem.meta.duration || 2;
      const points = [0.15, 0.5, 0.85].map(p => p * dur);
      for (const t of points) {
        await seekVideo(video, t);
        const predictions = await model.detect(video);
        predictions.filter(p => p.score > 0.45).forEach(p => labels.add(p.class));
        brightnessSum += await measureBrightness(video);
        brightnessCount += 1;
      }
    }
    if (brightnessCount) mediaItem.meta.brightness = brightnessSum / brightnessCount;
    return [...labels].map(c => ({ class: c, score: 1 }));
  } catch (e) {
    console.warn('Detection failed', e);
    return [];
  }
}

async function runVisionAnalysis() {
  if (state.analysisRunning || !state.media.length) return;
  state.analysisRunning = true;

  const panel = $('#analysis-panel');
  const status = $('#analysis-status');
  const progress = $('#analysis-progress');
  const results = $('#analysis-results');
  panel.classList.remove('hidden');
  status.textContent = 'Starting…';
  progress.style.width = '0%';
  results.innerHTML = '';

  let visionOk = true;
  try {
    await loadCocoModel();
    toast('Vision model ready', 'ok');
  } catch (e) {
    visionOk = false;
    status.textContent = 'Vision model unavailable — using heuristics only';
    toast('Vision CDN unavailable — heuristic scores only', 'error');
  }

  const preferred = (state.selectedTemplate && state.selectedTemplate.preferred) || [];
  const total = state.media.length;

  for (let i = 0; i < total; i++) {
    const m = state.media[i];
    status.textContent = visionOk
      ? 'Analyzing ' + (i + 1) + '/' + total + (m.type === 'video' ? ' (multi-frame)' : '') + '…'
      : 'Scoring ' + (i + 1) + '/' + total + '…';

    if (visionOk) {
      const detections = await detectObjects(m);
      m.labels = detections.map(d => d.class);
    } else {
      m.labels = [];
    }

    m.score = computeMediaScore(m, preferred);
    m.selected = m.score >= 52;
    progress.style.width = ((i + 1) / total * 100) + '%';
    await sleep(20);
  }

  state.media = applySelectionRules(state.media);
  status.textContent = 'Complete';
  const avg = Math.round(state.media.reduce((s, m) => s + m.score, 0) / total);
  const allLabels = [...new Set(state.media.flatMap(m => m.labels))].slice(0, 8);
  results.innerHTML =
    'Analyzed <strong>' + total + '</strong> items on-device' + (visionOk ? ' (multi-frame for videos)' : '') + '.<br>' +
    'Selected <strong class="score">' + state.media.filter(m => m.selected).length + '</strong> best clips (avg score ' + avg + ').<br>' +
    'Detected: ' + (allLabels.length ? allLabels.join(', ') : 'general scenes') + '.' +
    '<p class="hint-muted">Preview cycles every selected scene. Export burns captions via canvas overlay.</p>';

  renderMediaGrid();
  state.analysisRunning = false;
  setTimeout(() => generatePreview(), 350);
}

function stopPreviewSequencer() {
  state.previewPlaying = false;
  if (state.previewTimer) {
    clearTimeout(state.previewTimer);
    state.previewTimer = null;
  }
  const v = $('#preview-video');
  if (v) {
    try { v.pause(); } catch (_) {}
    v.onended = null;
  }
}

function showPreviewItem(item, index, total) {
  const video = $('#preview-video');
  const img = $('#preview-image');
  const frame = $('#reel-frame');
  const badge = $('#preview-scene-badge');
  if (badge) {
    badge.style.display = 'block';
    badge.textContent = (index + 1) + ' / ' + total;
  }
  frame.style.backgroundImage = 'none';

  if (item.type === 'video') {
    if (img) img.style.display = 'none';
    video.style.display = 'block';
    video.src = item.url;
    video.muted = state.muted;
    video.loop = false;
    video.currentTime = 0;
    video.play().catch(() => {});
  } else {
    video.style.display = 'none';
    try { video.pause(); } catch (_) {}
    if (img) {
      img.src = item.url;
      img.style.display = 'block';
    } else {
      frame.style.backgroundImage = 'url(' + item.url + ')';
      frame.style.backgroundSize = 'cover';
      frame.style.backgroundPosition = 'center';
    }
  }
}

function scheduleNextPreview(selected, index) {
  stopPreviewSequencer();
  if (!selected.length) return;
  state.previewPlaying = true;
  state.previewIndex = index % selected.length;
  const item = selected[state.previewIndex];
  showPreviewItem(item, state.previewIndex, selected.length);
  const dwellMs = item.type === 'image' ? 2500 : Math.min(3800, Math.max(1800, (item.meta.duration || 3) * 1000));
  const video = $('#preview-video');
  if (item.type === 'video' && video) {
    video.onended = () => {
      if (!state.previewPlaying) return;
      scheduleNextPreview(selected, state.previewIndex + 1);
    };
    state.previewTimer = setTimeout(() => {
      if (!state.previewPlaying) return;
      scheduleNextPreview(selected, state.previewIndex + 1);
    }, dwellMs + 500);
  } else {
    state.previewTimer = setTimeout(() => {
      if (!state.previewPlaying) return;
      scheduleNextPreview(selected, state.previewIndex + 1);
    }, dwellMs);
  }
}

function generatePreview() {
  showScreen('preview');
  const placeholder = $('#reel-placeholder');
  const video = $('#preview-video');
  const img = $('#preview-image');
  const caption = $('#preview-caption');

  placeholder.style.display = 'flex';
  if (video) video.style.display = 'none';
  if (img) img.style.display = 'none';
  $('#processing-text').textContent = 'Preparing multi-clip preview…';
  $('#render-progress').style.width = '50%';
  $('#preview-status').textContent = 'Building…';

  setTimeout(() => {
    $('#render-progress').style.width = '100%';
    placeholder.style.display = 'none';
    $('#preview-status').textContent = 'Playing';

    const selected = state.media.filter(m => m.selected);
    caption.textContent = state.captions.join('\n');
    applyCaptionStyle(caption);
    caption.oninput = () => {
      state.captions = caption.innerText.split('\n').filter(Boolean);
    };

    renderTimeline(selected);
    if (selected.length) scheduleNextPreview(selected, 0);
    else toast('No clips selected');
  }, 400);
}

function applyCaptionStyle(el) {
  const b = state.branding;
  el.style.color = b.mode === 'text' ? b.color : 'transparent';
  el.style.webkitTextStroke = b.mode === 'stroke' ? '2px ' + b.color : '0';
  el.style.fontFamily = b.font;
  el.style.fontWeight = b.style === 'bold' ? '800' : '700';
  el.style.textTransform = b.style === 'uppercase' ? 'uppercase' : 'none';
  el.style.filter = 'hue-rotate(' + b.hue + 'deg) saturate(' + b.saturation + '%) brightness(' + b.brightness + '%)';
  el.style.textShadow = b.style === 'shadow' ? '0 4px 12px rgba(0,0,0,0.7)' : '0 2px 8px rgba(0,0,0,0.5)';
}

function renderTimeline(selected) {
  const strip = $('#scenes-strip');
  strip.innerHTML = selected.map((m, i) =>
    '<div class="scene-thumb ' + (i === 0 ? 'active' : '') + '" draggable="true" data-idx="' + i + '">' +
    (m.type === 'video' ? '<video src="' + m.url + '" muted></video>' : '<img src="' + m.url + '">') +
    '<div class="scene-score">' + m.score + '</div>' +
    (m.labels.length ? '<div class="scene-labels">' + m.labels.slice(0, 2).join(', ') + '</div>' : '') +
    '</div>'
  ).join('');

  let dragSrc = null;
  $$('.scene-thumb').forEach(thumb => {
    thumb.addEventListener('click', () => {
      const idx = +thumb.dataset.idx;
      const sel = state.media.filter(m => m.selected);
      stopPreviewSequencer();
      scheduleNextPreview(sel, idx);
      $$('.scene-thumb').forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
    });
    thumb.addEventListener('dragstart', e => {
      dragSrc = thumb;
      thumb.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    thumb.addEventListener('dragend', () => thumb.classList.remove('dragging'));
    thumb.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
    thumb.addEventListener('drop', e => {
      e.preventDefault();
      if (dragSrc && dragSrc !== thumb) {
        const from = +dragSrc.dataset.idx;
        const to = +thumb.dataset.idx;
        const sel = state.media.filter(m => m.selected);
        const item = sel.splice(from, 1)[0];
        sel.splice(to, 0, item);
        const unselected = state.media.filter(m => !m.selected);
        state.media = sel.concat(unselected);
        renderTimeline(sel);
        scheduleNextPreview(sel, 0);
      }
    });
  });
}

function createCaptionOverlayPng(text, branding) {
  return new Promise((resolve, reject) => {
    const W = 1080, H = 1920;
    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    if (!ctx) { reject(new Error('Canvas unavailable')); return; }
    ctx.clearRect(0, 0, W, H);

    const raw = sanitizeCaptionText(text, 120);
    if (!raw) {
      canvas.toBlob(b => (b ? resolve(b) : reject(new Error('toBlob failed'))), 'image/png');
      return;
    }

    const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
    const displayLines = lines.length ? lines.slice() : [raw];
    const fontSize = displayLines.length > 2 ? 42 : 52;
    const fontWeight = branding.style === 'bold' ? '800' : '700';
    const fontFamily = branding.font || 'Inter, system-ui, sans-serif';
    ctx.font = fontWeight + ' ' + fontSize + 'px ' + fontFamily;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (branding.style === 'uppercase') {
      for (let i = 0; i < displayLines.length; i++) displayLines[i] = displayLines[i].toUpperCase();
    }

    const lineHeight = fontSize * 1.25;
    const blockHeight = displayLines.length * lineHeight + 28;
    const boxY = H * 0.78;
    const boxH = Math.min(blockHeight, H * 0.18);
    const boxX = W * 0.08;
    const boxW = W * 0.84;

    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    roundRect(ctx, boxX, boxY, boxW, boxH, 16);
    ctx.fill();

    const color = branding.mode === 'stroke' ? '#ffffff' : (branding.color || '#ffffff');
    const startY = boxY + boxH / 2 - ((displayLines.length - 1) * lineHeight) / 2;

    displayLines.forEach((line, i) => {
      const y = startY + i * lineHeight;
      if (branding.mode === 'stroke') {
        ctx.strokeStyle = branding.color || '#ffffff';
        ctx.lineWidth = 4;
        ctx.strokeText(line, W / 2, y);
        ctx.fillStyle = '#000000';
        ctx.fillText(line, W / 2, y);
      } else {
        if (branding.style === 'shadow') {
          ctx.fillStyle = 'rgba(0,0,0,0.65)';
          ctx.fillText(line, W / 2 + 3, y + 3);
        }
        ctx.fillStyle = color;
        ctx.fillText(line, W / 2, y);
      }
    });

    canvas.toBlob(b => (b ? resolve(b) : reject(new Error('toBlob failed'))), 'image/png');
  });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function getFFmpeg() {
  if (window.FFmpegWASM && window.FFmpegWASM.FFmpeg) return window.FFmpegWASM.FFmpeg;
  if (window.FFmpeg) return window.FFmpeg;
  return null;
}
function getUtil() { return window.FFmpegUtil || {}; }

async function loadFFmpeg() {
  if (state.ffmpegLoaded) return state.ffmpeg;
  const FFmpegClass = getFFmpeg();
  if (!FFmpegClass) throw new Error('FFmpeg.wasm not loaded — check network / CDN');
  const ffmpeg = new FFmpegClass();
  state.ffmpeg = ffmpeg;
  ffmpeg.on('log', ({ message }) => console.log('[ffmpeg]', message));
  ffmpeg.on('progress', ({ progress }) => {
    const pct = Math.min(98, Math.round(progress * 100));
    $('#render-progress').style.width = pct + '%';
    $('#processing-text').textContent = 'Rendering ' + pct + '%';
  });
  const { toBlobURL } = getUtil();
  if (!toBlobURL) throw new Error('FFmpeg util (toBlobURL) missing');
  const base = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
  await ffmpeg.load({
    coreURL: await toBlobURL(base + '/ffmpeg-core.js', 'text/javascript'),
    wasmURL: await toBlobURL(base + '/ffmpeg-core.wasm', 'application/wasm')
  });
  state.ffmpegLoaded = true;
  return ffmpeg;
}

async function renderAndExport() {
  stopPreviewSequencer();
  showScreen('preview');
  const placeholder = $('#reel-placeholder');
  const videoEl = $('#preview-video');
  const imgEl = $('#preview-image');
  placeholder.style.display = 'flex';
  if (videoEl) videoEl.style.display = 'none';
  if (imgEl) imgEl.style.display = 'none';
  $('#processing-text').textContent = 'Loading FFmpeg.wasm…';
  $('#render-progress').style.width = '3%';
  $('#preview-status').textContent = 'Rendering…';

  try {
    const ffmpeg = await loadFFmpeg();
    const { fetchFile } = getUtil();
    const selected = state.media.filter(m => m.selected).slice(0, 7);
    if (!selected.length) throw new Error('No clips selected');

    $('#processing-text').textContent = 'Writing media…';
    for (let i = 0; i < selected.length; i++) {
      const data = await fetchFile(selected[i].file);
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      await ffmpeg.writeFile('in' + i + '.' + ext, data);
    }
    if (state.customAudio) {
      const adata = await fetchFile(state.customAudio.file);
      await ffmpeg.writeFile('audio.mp3', adata);
    }

    let hasCaption = false;
    try {
      const rawCaption = ($('#preview-caption') && $('#preview-caption').innerText) || state.captions.join('\n');
      const pngBlob = await createCaptionOverlayPng(rawCaption, state.branding);
      const pngData = new Uint8Array(await pngBlob.arrayBuffer());
      await ffmpeg.writeFile('caption.png', pngData);
      hasCaption = true;
    } catch (e) {
      console.warn('Caption PNG failed', e);
      toast('Caption overlay skipped', 'error');
    }

    const preset = state.quality === 'high' ? 'medium' : state.quality === 'balanced' ? 'fast' : 'ultrafast';
    const crf = state.quality === 'high' ? '20' : state.quality === 'balanced' ? '24' : '28';

    const inputs = [];
    const filters = [];
    for (let i = 0; i < selected.length; i++) {
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      inputs.push('-i', 'in' + i + '.' + ext);
      const dur = selected[i].type === 'image' ? 2.8 : 3.8;
      filters.push(
        '[' + i + ':v]scale=1080:1920:force_original_aspect_ratio=decrease,' +
        'pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,' +
        'trim=duration=' + dur + ',setpts=PTS-STARTPTS[v' + i + ']'
      );
    }

    const concat = selected.map((_, i) => '[v' + i + ']').join('') + 'concat=n=' + selected.length + ':v=1:a=0[outv]';
    let fc = filters.join(';') + ';' + concat;
    if (hasCaption) {
      inputs.push('-i', 'caption.png');
      const capIdx = selected.length;
      fc += ';[outv][' + capIdx + ':v]overlay=0:0:format=auto[final]';
    }

    $('#processing-text').textContent = 'Compositing scenes…';
    const mapLabel = hasCaption ? '[final]' : '[outv]';
    await ffmpeg.exec([
      ...inputs,
      '-filter_complex', fc,
      '-map', mapLabel,
      '-c:v', 'libx264',
      '-preset', preset,
      '-crf', crf,
      '-pix_fmt', 'yuv420p',
      '-movflags', '+faststart',
      'temp.mp4'
    ]);

    $('#processing-text').textContent = 'Finalizing…';
    if (state.customAudio) {
      await ffmpeg.exec(['-i', 'temp.mp4', '-i', 'audio.mp3', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '128k', '-shortest', 'out.mp4']);
    } else {
      await ffmpeg.exec(['-i', 'temp.mp4', '-c', 'copy', 'out.mp4']);
    }

    const data = await ffmpeg.readFile('out.mp4');
    state.renderedBlob = new Blob([data.buffer], { type: 'video/mp4' });

    for (let i = 0; i < selected.length; i++) {
      const ext = selected[i].type === 'video' ? 'mp4' : 'jpg';
      try { await ffmpeg.deleteFile('in' + i + '.' + ext); } catch (_) {}
    }
    try { await ffmpeg.deleteFile('temp.mp4'); } catch (_) {}
    try { await ffmpeg.deleteFile('out.mp4'); } catch (_) {}
    try { await ffmpeg.deleteFile('caption.png'); } catch (_) {}
    if (state.customAudio) try { await ffmpeg.deleteFile('audio.mp3'); } catch (_) {}

    const sizeMB = (state.renderedBlob.size / 1024 / 1024).toFixed(1);
    $('#export-meta').innerHTML =
      selected.length + ' scenes • ' + state.quality + ' quality • ' + sizeMB + ' MB<br>' +
      'Template: ' + ((state.selectedTemplate && state.selectedTemplate.title) || 'Custom') +
      ' • Captions: ' + (hasCaption ? 'canvas overlay' : 'none') + ' • On-device';
    showScreen('export');
    toast('Reel ready', 'ok');
  } catch (err) {
    console.error(err);
    $('#processing-text').textContent = 'Render failed';
    $('#preview-status').textContent = 'Error';
    toast('Render failed: ' + (err.message || err), 'error');
    placeholder.style.display = 'none';
    const selected = state.media.filter(m => m.selected);
    if (selected.length) scheduleNextPreview(selected, 0);
  }
}

function initExport() {
  $('#export-btn').addEventListener('click', () => renderAndExport());
  $('#back-to-media').addEventListener('click', () => {
    stopPreviewSequencer();
    showScreen('media');
  });

  $('#download-btn').addEventListener('click', () => {
    if (!state.renderedBlob) return;
    const a = document.createElement('a');
    const url = URL.createObjectURL(state.renderedBlob);
    a.href = url;
    a.download = 'roll-reel-' + Date.now() + '.mp4';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
  });

  $('#share-ig-btn').addEventListener('click', async () => {
    if (!state.renderedBlob || !navigator.share) {
      toast('Web Share not available — use Download');
      return;
    }
    try {
      const file = new File([state.renderedBlob], 'roll-reel.mp4', { type: 'video/mp4' });
      await navigator.share({ files: [file], title: 'My Reel' });
    } catch (e) { console.log(e); }
  });

  $('#create-another').addEventListener('click', () => {
    revokeAllMedia();
    renderMediaGrid();
    $('#generate-btn').disabled = true;
    $('#analysis-panel').classList.add('hidden');
    $('#audio-hint').textContent = '';
    showScreen('home');
  });

  $('#reanalyze-btn') && $('#reanalyze-btn').addEventListener('click', () => {
    stopPreviewSequencer();
    showScreen('media');
    runVisionAnalysis();
  });

  $('#edit-captions-btn') && $('#edit-captions-btn').addEventListener('click', () => {
    const c = $('#preview-caption');
    if (c) {
      c.focus();
      try { document.execCommand('selectAll', false, null); } catch (_) {}
    }
  });

  $('#toggle-mute-btn') && $('#toggle-mute-btn').addEventListener('click', () => {
    state.muted = !state.muted;
    const v = $('#preview-video');
    if (v) v.muted = state.muted;
    $('#toggle-mute-btn').innerHTML = state.muted ? '<span>🔇</span> Mute' : '<span>🔊</span> Sound';
  });
}

function showPrivacy() {
  alert(
    'Privacy Guarantee\n\n' +
    '• Media never leaves this device\n' +
    '• TensorFlow.js + COCO-SSD run 100% locally\n' +
    '• FFmpeg.wasm renders the final MP4 in your browser\n' +
    '• Captions are drawn with canvas (browser fonts), not uploaded\n' +
    '• No accounts, no servers, no tracking of your content\n' +
    '• Refresh the page to wipe everything'
  );
}

function initNav() {
  $('#back-btn').addEventListener('click', () => {
    const map = { branding: 'home', media: 'branding', preview: 'media', export: 'preview' };
    if (map[state.currentScreen]) showScreen(map[state.currentScreen]);
  });
  $('#privacy-btn').addEventListener('click', showPrivacy);
  $$('.tab-item').forEach(item => {
    item.addEventListener('click', () => {
      if (item.dataset.action === 'privacy') { showPrivacy(); return; }
      const screen = item.dataset.screen;
      if (screen) showScreen(screen);
    });
  });
}

function updateTime() {
  const n = new Date();
  const el = $('#status-time');
  if (el) {
    el.textContent = n.getHours().toString().padStart(2, '0') + ':' + n.getMinutes().toString().padStart(2, '0');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  renderTemplates();
  initBranding();
  initMedia();
  initExport();
  initNav();
  updateTime();
  setInterval(updateTime, 30000);
});

window.RollHelpers = {
  sanitizeCaptionText,
  computeMediaScore,
  countTemplateMatches,
  applySelectionRules,
  validateMediaFile,
  createCaptionOverlayPng
};
