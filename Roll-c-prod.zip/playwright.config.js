import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  use: {
    baseURL: 'http://127.0.0.1:4173',
    headless: true
  },
  webServer: {
    command: 'npx --yes serve -l 4173 .',
    port: 4173,
    reuseExistingServer: true,
    timeout: 30_000
  }
});
