# Roll — Camera Roll → Reels

Privacy-first, **100% on-device** browser app that turns photos & videos into vertical Reels.

**Stack:** TensorFlow.js + COCO-SSD · FFmpeg.wasm · Canvas caption overlay · multi-clip preview

## What’s production-hardened (v0.3)

| Feature | Approach |
|---------|----------|
| **Captions** | Drawn on a transparent 1080×1920 canvas PNG, then `overlay` in FFmpeg — **no drawtext fonts** (the reliable pattern used by most FFmpeg.wasm apps) |
| **Preview** | Cycles every selected scene (image ~2.5s, video up to ~3.8s); click timeline to jump |
| **Video vision** | 3-frame sample (15% / 50% / 85%) per video |
| **Memory** | Strict `revokeObjectURL` on remove / reset / download |
| **Limits** | 12 files · 25 MB each · ~80 MB total · 60s max video |
| **Failures** | Non-blocking toasts; render errors restore preview instead of dead-ending |
| **FFmpeg perf** | `npm start` serves with **COOP/COEP** so SharedArrayBuffer can work |

## Quick start

```bash
npm install          # optional — only for tests
npm start            # http://127.0.0.1:4173  (COOP/COEP headers)
npm test             # unit tests (pure scoring helpers)
npm run test:e2e     # Playwright smoke (after: npx playwright install chromium)
```

Open in Chrome/Edge/Safari. First analysis loads the vision model from CDN (once).

## Flow

1. Pick a template  
2. Style captions  
3. Drop photos/videos → **Analyze**  
4. Preview cycles all selected scenes → edit text / reorder  
5. **Render Final MP4** (canvas captions + optional audio)

## Privacy

Media, analysis, and render never leave the device. Refresh clears state.

## Limits & notes

- CDN required on **first** load for TF.js / FFmpeg core (then browser-cached).
- Use **Fast** quality on mobile if memory is tight.
- Only use audio you have rights to.

## License

MIT
