import { describe, it, expect } from 'vitest';
import {
  sanitizeCaptionForFFmpeg,
  countTemplateMatches,
  computeMediaScore,
  applySelectionRules,
  validateMediaFile
} from '../src/scoring.js';

describe('sanitizeCaptionForFFmpeg', () => {
  it('returns a single space for empty / non-string', () => {
    expect(sanitizeCaptionForFFmpeg('')).toBe(' ');
    expect(sanitizeCaptionForFFmpeg(null)).toBe(' ');
    expect(sanitizeCaptionForFFmpeg(undefined)).toBe(' ');
  });

  it('strips newlines and collapses whitespace', () => {
    expect(sanitizeCaptionForFFmpeg('Hello\nWorld\r\n  !')).toBe('Hello World !');
  });

  it('removes characters dangerous for drawtext', () => {
    const out = sanitizeCaptionForFFmpeg("It's a test: path\\with% {brackets}");
    expect(out).not.toMatch(/[':\\%{}[\]]/);
    expect(out.length).toBeGreaterThan(0);
  });

  it('truncates to maxLen', () => {
    const long = 'a'.repeat(200);
    expect(sanitizeCaptionForFFmpeg(long, 40).length).toBeLessThanOrEqual(40);
  });
});

describe('countTemplateMatches', () => {
  it('counts substring matches either direction', () => {
    expect(countTemplateMatches(['person', 'sports ball'], ['person', 'ball'])).toBe(2);
    expect(countTemplateMatches(['dog'], ['person'])).toBe(0);
    expect(countTemplateMatches([], ['person'])).toBe(0);
  });
});

describe('computeMediaScore', () => {
  const baseImage = {
    type: 'image',
    meta: { width: 1080, height: 1920, duration: 0, brightness: 0.5, aspect: 1080 / 1920 },
    labels: []
  };

  it('scores a good 9:16 image reasonably high', () => {
    const score = computeMediaScore(baseImage, []);
    expect(score).toBeGreaterThanOrEqual(60);
    expect(score).toBeLessThanOrEqual(99);
  });

  it('boosts when person is detected', () => {
    const without = computeMediaScore(baseImage, []);
    const withPerson = computeMediaScore({ ...baseImage, labels: ['person'] }, []);
    expect(withPerson).toBe(without + 10);
  });

  it('boosts template preferred matches', () => {
    const preferred = ['person', 'sports ball'];
    const score = computeMediaScore(
      { ...baseImage, labels: ['person', 'sports ball'] },
      preferred
    );
    const base = computeMediaScore(baseImage, preferred);
    // +10 person + 2*12 matches
    expect(score).toBe(base + 10 + 24);
  });

  it('is deterministic (no random)', () => {
    const a = computeMediaScore(baseImage, ['person']);
    const b = computeMediaScore(baseImage, ['person']);
    expect(a).toBe(b);
  });

  it('rewards short videos in the sweet spot', () => {
    const good = computeMediaScore({
      type: 'video',
      meta: { width: 1080, height: 1920, duration: 4, brightness: 0.5, aspect: 9 / 16 },
      labels: []
    }, []);
    const long = computeMediaScore({
      type: 'video',
      meta: { width: 1080, height: 1920, duration: 40, brightness: 0.5, aspect: 9 / 16 },
      labels: []
    }, []);
    expect(good).toBeGreaterThan(long);
  });
});

describe('applySelectionRules', () => {
  it('selects high scores and caps at 8', () => {
    const media = Array.from({ length: 12 }, (_, i) => ({
      score: 90 - i,
      selected: false
    }));
    const result = applySelectionRules(media);
    const selected = result.filter(m => m.selected);
    expect(selected.length).toBeLessThanOrEqual(8);
    expect(selected.length).toBeGreaterThan(0);
  });

  it('forces at least 2 selections when possible', () => {
    const media = [
      { score: 40, selected: false },
      { score: 30, selected: false },
      { score: 20, selected: false }
    ];
    const result = applySelectionRules(media);
    expect(result.filter(m => m.selected).length).toBeGreaterThanOrEqual(2);
  });
});

describe('validateMediaFile', () => {
  it('rejects non image/video', () => {
    const f = { type: 'application/pdf', size: 100, name: 'x.pdf' };
    expect(validateMediaFile(f).ok).toBe(false);
  });

  it('rejects oversized files', () => {
    const f = { type: 'image/jpeg', size: 30 * 1024 * 1024, name: 'big.jpg' };
    expect(validateMediaFile(f).ok).toBe(false);
  });

  it('accepts normal image', () => {
    const f = { type: 'image/png', size: 1024, name: 'ok.png' };
    expect(validateMediaFile(f).ok).toBe(true);
  });
});
