/**
 * Pure scoring & caption helpers for Roll.
 * Safe to unit-test without DOM / TensorFlow / FFmpeg.
 */

/**
 * Sanitize caption text for display / overlay (canvas path).
 * @param {string} text
 * @param {number} [maxLen=90]
 * @returns {string}
 */
export function sanitizeCaptionForFFmpeg(text, maxLen = 90) {
  // Kept name for test compatibility; canvas path doesn't need FFmpeg-char stripping
  // but we still normalize whitespace and length.
  if (!text || typeof text !== 'string') return ' ';
  let s = text
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/[\\]/g, '')
    .trim();
  if (s.length > maxLen) s = s.slice(0, maxLen).trim();
  return s || ' ';
}

export function countTemplateMatches(labels = [], preferred = []) {
  if (!labels.length || !preferred.length) return 0;
  return labels.filter((l) =>
    preferred.some((p) => l.includes(p) || p.includes(l))
  ).length;
}

export function computeMediaScore(media, preferred = []) {
  const meta = media.meta || {};
  let score = 35;
  const res = (meta.width || 0) * (meta.height || 0);
  if (res > 1_200_000) score += 18;
  else if (res > 500_000) score += 10;
  if (media.type === 'video') {
    const d = meta.duration || 0;
    if (d >= 1.5 && d <= 15) score += 14;
    else if (d > 0) score += 4;
  } else score += 7;
  const aspectDiff = Math.abs((meta.aspect || 1) - 9 / 16);
  if (aspectDiff < 0.25) score += 14;
  else if (aspectDiff < 0.55) score += 6;
  const b = meta.brightness ?? 0.5;
  if (b > 0.22 && b < 0.82) score += 8;
  score += countTemplateMatches(media.labels || [], preferred) * 12;
  if ((media.labels || []).includes('person')) score += 10;
  return Math.min(99, Math.round(score));
}

export function applySelectionRules(media) {
  const sorted = [...media].sort((a, b) => b.score - a.score);
  sorted.forEach((m) => { m.selected = m.score >= 52; });
  let selected = sorted.filter((m) => m.selected);
  if (selected.length < 2 && sorted.length > 0) {
    sorted.slice(0, Math.min(5, sorted.length)).forEach((m) => { m.selected = true; });
    selected = sorted.filter((m) => m.selected);
  }
  let kept = 0;
  sorted.forEach((m) => {
    if (m.selected) {
      kept += 1;
      if (kept > 8) m.selected = false;
    }
  });
  return sorted;
}

export function validateMediaFile(file, opts = {}) {
  const maxBytes = opts.maxBytes ?? 25 * 1024 * 1024;
  if (!file) return { ok: false, reason: 'No file' };
  if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
    return { ok: false, reason: 'Only images and videos are supported' };
  }
  if (file.size > maxBytes) {
    const mb = (maxBytes / (1024 * 1024)).toFixed(0);
    return { ok: false, reason: `File too large (max ${mb} MB): ${file.name}` };
  }
  return { ok: true };
}
