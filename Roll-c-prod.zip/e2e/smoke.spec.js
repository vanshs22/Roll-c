import { test, expect } from '@playwright/test';

test.describe('Roll smoke', () => {
  test('home screen loads with templates', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('h1')).toContainText('Roll');
    await expect(page.locator('#templates-grid .template-card')).toHaveCount(5);
  });

  test('can open branding from a template', async ({ page }) => {
    await page.goto('/');
    await page.locator('.use-btn').first().click();
    await expect(page.locator('#screen-branding')).toHaveClass(/active/);
    await expect(page.locator('#live-caption')).toBeVisible();
  });

  test('privacy button shows guarantee', async ({ page }) => {
    await page.goto('/');
    page.once('dialog', async dialog => {
      expect(dialog.message()).toMatch(/Privacy Guarantee/i);
      await dialog.dismiss();
    });
    await page.locator('#privacy-btn').click();
  });

  test('media screen is reachable', async ({ page }) => {
    await page.goto('/');
    await page.locator('.use-btn').first().click();
    await page.locator('#continue-branding').click();
    await expect(page.locator('#screen-media')).toHaveClass(/active/);
    await expect(page.locator('#upload-zone')).toBeVisible();
    await expect(page.locator('#generate-btn')).toBeDisabled();
  });
});
